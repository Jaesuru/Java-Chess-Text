package test;
import game.*;

import java.util.ArrayList;
import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		// Ask for players' names
		System.out.print("Enter name for Player 1 (White): ");
		String player1Name = sc.nextLine();

		System.out.print("Enter name for Player 2 (Black): ");
		String player2Name = sc.nextLine();

		System.out.println("Ready for a game of Chess?");

		Game game = new Game(player1Name, player2Name);
		game.showBoard(System.out);

		while (true) {
			if (game.isWhiteTurn()) {
				System.out.println(player1Name + "'s turn (White)!\n");
			} else {
				System.out.println(player2Name + "'s turn (Black)!\n");
			}

			System.out.println("Game commands listed below:");
			System.out.println("- mv (move)\t- cp (capture)\t- undo\t- print status");
			System.out.println("Enter command below: \n");

			String userInput = sc.nextLine();

			if (userInput.startsWith("mv") || userInput.startsWith("cp")) {
				String[] userMove = userInput.split(" ");

				if (userMove.length == 2 && validMovement(userMove[1])) {
					Move move = new Move(userMove[1]);
					if (userInput.startsWith("mv")) {
						if (game.getPiece(move.getRow1(), move.getCol1()) != null) {
							System.out.println("Invalid move, tile is already occupied.\n");
							continue;
						}
						if (game.move(move)) {
							if (game.isWhiteTurn()) {
								System.out.println(player2Name + " moves: " + move + "\n");
							} else {
								System.out.println(player1Name + " moves: " + move + "\n");
							}
						} else {
							System.out.println("Illegal move.\n");
						}
					} else if (userInput.startsWith("cp")) {
						if (game.getPiece(move.getRow1(), move.getCol1()) == null) {
							System.out.println("Illegal capture.\n");
							continue;
						}
						if (game.move(move)) {
							if (game.isWhiteTurn()) {
								System.out.println(player2Name + " captures: " + move + "\n");
							} else {
								System.out.println(player1Name + " captures: " + move + "\n");
							}
						} else {
							System.out.println("Illegal move.\n");
						}
					}
					game.showBoard(System.out);
				} else {
					System.out.println("Invalid command.\n");
				}

			} else if (userInput.equalsIgnoreCase("undo")) {
				Game anotherGame = new Game(game.getPlayer1(), game.getPlayer2());

				ArrayList<Move> undoGame = game.getMoves();
				for (int i = 0; i < undoGame.size() - 1; i++) {
					anotherGame.move(undoGame.get(i));
				}

				game = anotherGame;
				System.out.println("Undo complete!\n");
			} else if (userInput.equalsIgnoreCase("print status")) {
				game.showBoard(System.out);
			} else {
				System.out.println("Invalid command.\n");
			}
		}
	}

	private static boolean validMovement(String move) {
		return move.matches("[a-h][1-8][a-h][1-8]");
	}
}
